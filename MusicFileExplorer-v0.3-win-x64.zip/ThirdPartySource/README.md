# Third-party library source for Music File Explorer v0.3

| Component | Source in this folder | Upstream reference |
| --- | --- | --- |
| libsndfile 1.2.2 | `libsndfile-1.2.2.tar.xz` and `libsndfile-1.2.2-build-tree.zip` | [Release 1.2.2](https://github.com/libsndfile/libsndfile/releases/tag/1.2.2) and [commit `72f6af1`](https://github.com/libsndfile/libsndfile/tree/72f6af15e8f85157bd622ed45b979025828b7001) |
| SoundTouch.Net 2.3.2 | `SoundTouch.Net-2.3.2.zip` | [NuGet package repository commit `98e5b8f`](https://github.com/owoudenberg/soundtouch.net/tree/98e5b8fd2f8efed0ddf7c8f66b435bfb231659dc) |
| TagLibSharp 2.3.0 | `TagLibSharp-2.3.0-source.zip` | [Release tag at commit `b5ae84f`](https://github.com/mono/taglib-sharp/tree/b5ae84f2e84087bf160bb0471420200dd2b5d809) |
| LAME 3.100 | `lame-3.100.tar.gz` | [Upstream project](https://sourceforge.net/projects/lame/files/lame/3.100/) |
| mpg123 1.31.3 | `mpg123-1.31.3.tar.bz2` | [Upstream source](https://www.mpg123.de/download/mpg123-1.31.3.tar.bz2) |
| libogg 1.3.5 | `libogg-1.3.5.tar.gz` | [Upstream v1.3.5](https://gitlab.xiph.org/xiph/ogg/-/tree/v1.3.5) |
| libFLAC 1.4.2 | `libflac-1.4.2.tar.gz` | [Upstream 1.4.2](https://github.com/xiph/flac/tree/1.4.2) |
| libvorbis 1.3.7 | `libvorbis-1.3.7.tar.gz` | [Upstream v1.3.7](https://github.com/xiph/vorbis/tree/v1.3.7) |
| Opus 1.4 | `opus-1.4.tar.gz` | [Upstream v1.4](https://github.com/xiph/opus/tree/v1.4) |

The source ZIP for TagLibSharp preserves the library project, signing key,
shared build files, and upstream licence. It omits audio and raw image fixtures used by unit tests. The upstream release includes those fixtures.

## Rebuilding the Windows native library

Use the libsndfile 1.2.2 build tree for the Windows CMake instructions, including
`README.md`, `vcpkg.json`, and `.github/workflows/action.yml`. The upstream
Windows x64 shared-library configuration uses Visual Studio 2022 and vcpkg's
`x64-windows-static` triplet for the codecs. Use the shared-library build of
libsndfile itself so the output is `sndfile.dll`.

The bundled `vcpkg-windows-codec-ports` directory contains the port recipes,
patches, and x64 triplet from [vcpkg commit `0fa8459`](https://github.com/microsoft/vcpkg/tree/0fa8459cf3a7caca7adc58f992bc32ff13630684).
All six codec source archives match the SHA-512 values in these recipes. The
mpg123 source and patches also reproduce the patch-set fingerprint `d919e8ea46`
recorded in the upstream `sndfile.dll`. The vcpkg snapshot provides the build
helpers referred to by the recipes. If building offline, use the included codec
archives to populate vcpkg's downloads cache with the filenames its recipes
expect.

For the managed libraries, use the project files in their source archives and
keep the exported interfaces compatible with the shipped DLLs. Source archives
are also provided for the permissively licensed native codecs to make rebuilding
`sndfile.dll` easier. See `../THIRD-PARTY-NOTICES.txt` for licence details.
